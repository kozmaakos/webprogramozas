<div class="col-sm-8">
        <h2>KÖVA-KOM Nonprofit Zrt. bemutatása</h2>
        
        <p>KÖVA-KOM Nonprofit Zrt. zártkörű részvénytársaságként működik 1991. december 20-a óta.A hulladékról szóló törvény értelmében 2014. január 1-jétől csak olyan szervezetek végezhetnek hulladékgazdálkodási közszolgáltatást, amelyek többségi állami, vagy önkormányzati tulajdonú nonprofit szervezetek. Ez volt az oka annak, hogy 2014-ben nonprofittá változott a Társaság, s így üzletszerű gazdasági tevékenységet csak kiegészítő jelleggel folytathat.Jelen Társaság esetében a közgyűlés hatáskörét az alapító, Nagykőrös Város Önkormányzata gyakorolja. A közgyűlés hatáskörébe tartozó kérdésekben az alapító írásban határoz és a döntés az ügyvezetéssel való közléssel válik hatályossá. Az igazgatóság jogait a vezérigazgató gyakorolja, és a vezérigazgató képviseli a Társaságot, továbbá jogosult önálló cégjegyzésre. A felügyelőbizottság 3 tagból áll, tagjait az alapító jelöli ki, 5 éves időtartamra.A KÖVA-KOM Nonprofit Zrt. helyi szolgáltatásokat ellátó, önkormányzati tulajdonú társaság. Tevékenysége több fő ágazatból áll, melyek a következőek:</p>
		<br>
        <h2>Hulladékgazdálkodás:</h2>
        <p>Társaságunk legjelentősebb tevékenysége a települési szilárd hulladék, szelektív hulladék gyűjtése, illetve a nem közművel összegyűjtött települési folyékony hulladék gyűjtése és szennyvíztisztító telepre történő szállítása, melyet kötelező helyi közszolgáltatás útján látunk el. A Zrt. feladatai közé tartozik települési köztisztasági feladok ellátása is: városi utak tisztítása, kézi tározók ürítése, valamint az illegális hulladékok elszállítása.</p>
		<h2>Távhőszolgáltatás:</h2>
		<p>Társaságunk 2013. július 1-től látja el Nagykőrös Város távhőszolgáltatását kettő fűtőművel.</p>
		<h2>Ingatlankezelés:</h2>
		<p>A Zrt. hatáskörébe tartozik a vagyonkezelői és bérbeadói jog gyakorlása, így a Társaság végzi a 188 önkormányzati és a 3 saját tulajdonú lakás, illetve a 43 önkormányzati és 24 saját tulajdonú üzlethelyiségek karbantartását, állagmegóvását, felújítását, korszerűsítését.</p>
		<h2>Városüzemeltetési feladatok ellátása:</h2>
		<p>A KÖVA-KOM Nonprofit Zrt. végzi a bel- és külterületi utak ellenőrzését, rendezését, karbantartását állagmegóvását és a III., IV., V., VI., VII. rendű utak ellenőrzését, város csapadékvíz elvezető rendszerének tisztántartását, karbantartását, forgalomirányítási eszközök vizsgálatát, szükség esetén a forgalommódosításhoz kapcsolódó táblák kihelyezését, megszüntetését. Mindezen túl szakfelügyeletet biztosítása az önkormányzati tulajdonú utak és csapadékvíz hálózat esetén.</p>
		<h2>Erdei iskola:</h2>
		<p>A Társaság hatáskörébe tartozik a nagykőrösi Pálfájai Oktatóközpont működtetése, karbantartása. Minden évben rendszerint megrendezésre kerülnek a gyerekek számára igénybe vehető nyári táborok – nappali és bentalvós –, havi rendszerességgel 5 órai teadélutánokon lehet részt venni, illetve a családoknak és iskoláknak Kutatónapot szerveznek a Pálfájában.</p>
		<h2>Piac-vásár:</h2>
		<p>Nagykőrös Város Önkormányzata a KÖVA-KOM Nonprofit Zrt. által minden hónap utolsó vasárnapján Országos Állat és Kirakodóvásárt rendez, és folyamatosan fenntartja, ellátja a Nagykőrösi Piac üzemeltetési feladatait.</p>
		</div>
</div>