            <div class="col-sm-4">
                <h2>Az alábbi linkeken elérhetik eredeti oldalunk:</h2>
                <ul class="nav nav-pills flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="http://www.kovart.hu">KÖVA-KOM Nonprofit Zrt.</a>
                    </li>
					<li class="nav-item">
                        <a class="nav-link" href="http://www.kovart.hu/index.php?lap=kozerdeku">Közérdekű adatok</a>
                    </li>
                </ul>
            </div>
            <div class="col-sm-8">
                <h2>KÖVA-KOM Nonprofit Zrt.</h2>
                <p>Főbb feladataink közé tartozik a hulladékgazdálkodás, távhőszolgáltatás, ingatlankezelés, városüzemeltetési feladatok ellátása.</p>
                <br>
                <div class="embed-responsive embed-responsive-16by9">
                    <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/unKP-CGwJfc" allowfullscreen></iframe>
                </div>
                <br>
                <h2>Nagykőrös virágos város</h2>
                <br>
                <div class="embed-responsive embed-responsive-21by9">
                    <video src="video/viragosvaros.mov" controls></video>
                </div>
                <p>„A hulladékhegyek mennyiségéből és minőségéből úgy tűnik, hogy a Földlakók minden energiájukkal azon fáradoznak, hogy a rendelkezésükre álló nyersanyagokat hulladékká alakítsák.” - Egy földönkívüli naplójából</p>
            </div>