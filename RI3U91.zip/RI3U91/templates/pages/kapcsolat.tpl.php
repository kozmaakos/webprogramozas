<div class="col-sm-8">
    <h2>Elérhetőségeink</h2>
    <h5>Email: kovart@kovart.hu</h5>
    <h5>Telefonszám: +36 53 550 250</h5>
    <h6>Amennyiben az ügyfélszolgálat foglalt vagy nem jelentkezik, kérlek írj e-mailt vagy üzenetet!</h6>
    <h2>Adataink:</h2>
    <h5>Forgalmazó: KÖVA-KOM Nonprofit Zrt.</h5>
    <h5>Székhely: 2750 Nagykőrös, Lőrinc pap utca 3.</h5>
    
</div>
    <h2 class="h1-responsive font-weight-bold text-center my-4">Adjon visszajelzést e-mail címünkre!</h2>
    <p class="text-center w-responsive mx-auto mb-5">Ha bármivel kapcsolatban kérdése van, vagy csak szeretné elmondani a véleményét írjon nekünk üzenetet, az alábbi adatok megadásával.</p>
    <div class="container-contact100">
		<div class="wrap-contact100">
			<form action="?oldal=uzenetek" method="post" class="contact100-form validate-form">
				<span class="contact100-form-title">
					Vegye fel velünk a kapcsolatot
				</span>
    <div class="wrap-input100 validate-input" data-validate="Név Kötelező">
					<input class="input100" id="name" type="text" pattern="[A-Z,a-z, ]*+[A-Z,a-z, ]*"  name="nev" placeholder="Név" required>
					<label class="label-input100" for="first">
						<span class="lnr lnr-user"></span>
					</label>
				</div>
                <div class="wrap-input100 validate-input" >
					<input class="input100" id="targy" type="text" name="targy" placeholder="Tárgy" required>
					<label class="label-input100" for="targy">
						<span class="lnr lnr-subject-handset"></span>
					</label>
				</div>
                <div class="wrap-input100 validate-input" >
					<input class="input100" id="email" type="text" name="email" placeholder="E-mail" title="Érvényes e-mail címet adjon meg!" required>
					<label class="label-input100" for="email">
						<span class="lnr lnr-envelope"></span>
					</label>
				</div>
        <div class="wrap-input100 validate-input" >
					<textarea class="input100" name="text" placeholder="Megjegyzés" required></textarea>
                </div>
                
            
            <div class="container-contact100-form-btn">
					<div class="wrap-contact100-form-btn">
						<div class="contact100-form-bgbtn">
						<button class="contact100-form-btn" method="post">
							Küldés
						</button>
						</div>
					</div>
				</div>
    </form>
</div>
</div>
    
        <div class="col-md-3 text-center">
            <ul class="list-unstyled mb-0">
                <li><i class="fas fa-map-marker-alt fa-2x"></i>
                    <p>2750 Nagykőrös, Lőrinc pap utca 3.</p>
                </li>

                <li><i class="fas fa-phone mt-4 fa-2x"></i>
                    <p>+36 53 550 250</p>
                </li>

                <li><i class="fas fa-envelope mt-4 fa-2x"></i>
                    <p>kovart@kovart.hu</p>
                </li>
            </ul>
        </div>

    

   