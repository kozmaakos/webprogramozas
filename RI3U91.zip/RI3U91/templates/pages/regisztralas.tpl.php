<form action = "?oldal=regisztral" method = "post">
<div class="col-md-9 mb-md-0 mb-5">
            

                <div class="row">
                    <div class="col-md-6">
                        <div class="md-form mb-0">
                            <input type="text" id="csnev" name="csnev" class="form-control" required>
                            <label for="name" class="">Családi név</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="md-form mb-0">
                            <input type="text" id="unev" name="unev" class="form-control" required>
                            <label for="unev" class="">Utó név</label>
                        </div>
                    </div>

                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="md-form mb-0">
                            <input type="text" id="fn" name="fn" class="form-control" required>
                            <label for="fn" class="">Felhasználónév</label>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <div class="md-form mb-0">
                            <input type="password" id="pw" name="pw" class="form-control" required>
                            <label for="pw" class="">Jelszó</label>
                        </div>
                    </div>
                </div>
            

            <div class="text-center text-md-left">
            <input type="submit" name="regisztracio" class="gomb" value="Regisztráció">
            </div>
            <div class="status"></div>
        </div>
        </form>